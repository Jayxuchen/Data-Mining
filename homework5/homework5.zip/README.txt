Jason Chen

python version -- Python 2.7.6

run python association-rules.py yelp4.csv minsup minconf

Everything Works as long as you put in the right number of arguments

Output displays the number of frequent itemsets in each size of k elements per itemset
along with the total frequent itemsets and total Association rules with a single-variable in the consequent

"Total Itemsets" in output refers to Total Frequent Itemsets
