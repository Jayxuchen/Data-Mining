Jason Chen

python version -- Python 2.7.6

run nbc.py with two arguments, arg1 - training set csv, and arg2 - test set csv
