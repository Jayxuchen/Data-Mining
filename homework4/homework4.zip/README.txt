Jason Chen

python version -- Python 2.7.6

run python kmeans.py yelp3.csv K {1-5} {1,2,no}

Everything Works as long as you put in the right number of arguments

